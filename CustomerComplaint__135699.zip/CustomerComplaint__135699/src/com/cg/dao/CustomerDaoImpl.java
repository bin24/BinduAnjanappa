package com.cg.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.model.CustomerBean;


@Repository
public class CustomerDaoImpl implements ICustomerDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void add(CustomerBean bean) {
		
		
		entityManager.persist(bean);
		entityManager.flush();	//required to reflect changes on database
		
		
		
	}
	
	@Override
	public CustomerBean getById(int complaintId) {
		
		
		Query query = entityManager.createNamedQuery("getById", CustomerBean.class).setParameter("pCustId", complaintId);
		
		return (CustomerBean) query.getSingleResult();
		
		
		
	}

	
	

}
