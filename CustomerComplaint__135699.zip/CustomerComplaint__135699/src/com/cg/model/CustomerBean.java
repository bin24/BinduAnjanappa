package com.cg.model;

import java.util.Date;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TypedQuery;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;







import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="complaint")
@NamedQueries({
	
	@NamedQuery(name = "getById", query = "select detail from CustomerBean detail WHERE detail.complaintId=:pCustId"),
	
	
})
public class CustomerBean {
	
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	@Column(name="complaintId")
	private int complaintId;
	
	
	@Column(name="accountId")
	@Min(value=0,message="Can not be negative")
	@NotNull(message="Required")
	private int accountId;
	
	@Column(name="branchCode")
	@NotEmpty(message="Required")
	private String branchCode;
	
	@NotEmpty(message="Enter valid Email ID")
	@Email(message="Enter valid Email ID")
	@Column(name="emailId")
	private String emailId;
	
	@Column(name="category")
	@NotEmpty(message="Required")
	private String category;
	
	@Column(name="description")
	@NotEmpty(message="Required")
	private String description;
	
	@Column(name="priority")
	private String priority;
	
	@Column(name="status")
	private String status;
	
	
	public int getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

}


