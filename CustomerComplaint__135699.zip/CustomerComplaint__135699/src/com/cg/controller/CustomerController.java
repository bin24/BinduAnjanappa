package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.CustomerBean;
import com.cg.service.ICustomerService;



@Controller
public class CustomerController 
{
	@Autowired
	private ICustomerService service;
	

	public ICustomerService getService() {
		return service;
	}
	
	public void setService(ICustomerService service) {
		this.service = service;
	}
	@RequestMapping("/index")
	public String index()
	{
		return "index";
	}
	@RequestMapping("/register")
	public String start(Model model)
	{
		model.addAttribute("cust", new CustomerBean());
		return "home";
	}
	
	@RequestMapping("/resForm")
	public ModelAndView register(@ModelAttribute("cust") @Valid CustomerBean bean,BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("home","k",bean);
		}
		else
		{
			
		service.add(bean);
		return new ModelAndView("success","k",bean);
		}
	}
	
	@RequestMapping("/status")
	public String startById(Model model)
	{
		
		return "checkStatus";
	}
	
	
	@RequestMapping("/retrieveID")
	public ModelAndView retrieve(@RequestParam int complaintId)
	{
		
		return new ModelAndView("checkStatus","key",service.getById(complaintId));
	}
	
	
	

}
