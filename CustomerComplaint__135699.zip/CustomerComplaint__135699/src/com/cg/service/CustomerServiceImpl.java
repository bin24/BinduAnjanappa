package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;







import com.cg.dao.ICustomerDao;
import com.cg.model.CustomerBean;



@Service
@Transactional	//This annotation will make automatic transaction management 
public class CustomerServiceImpl implements ICustomerService {
	
	
	@Autowired
	private ICustomerDao dao;
	
	

	@Override
	public void add(CustomerBean bean) {
		
		if(bean.getCategory().equals("InternetBanking"))
		{
			bean.setPriority("High");
			bean.setStatus("Open");
			dao.add(bean);
		}
		else if(bean.getCategory().equals("GeneralBanking"))
		{
			bean.setPriority("Medium");
			bean.setStatus("Open");
			dao.add(bean);
		}
		else
		{
			bean.setPriority("Low");
			bean.setStatus("Open");
			dao.add(bean);
		}
		
		 
		
	}
	@Override
	public CustomerBean getById(int complaintId) {
		return dao.getById(complaintId);
		
	}






	



	

}
