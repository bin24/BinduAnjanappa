package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
//import java.util.Date;
import java.sql.Date;
import java.util.List;

import com.cg.obs.dto.Feedback;
import com.cg.obs.dto.Tracker;
import com.cg.obs.dto.Transaction;
import com.cg.obs.dto.User;
import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBConnection;

public class BankDAOImpl implements IBankDAO {
	
	/*******************************************************************************************************
	- Function Name	    :	validateCredentials()
	- Input Parameters	:	UserInfoDTO user
	- Return Type		:	UserInfoDTO
	- Throws			:  	BankException
	- Author			:	Capgemini-Group-3
	- Creation Date	    :	20/03/2017
	- Description		:	validates credentials
	********************************************************************************************************/
		
		@Override
		public User validateCredentials(String accNum,String pswd) throws BankException {
			// TODO Auto-generated method stub
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			User usr = null;
			int accNum1 = Integer.parseInt(accNum);

			try {
				conn = DBConnection.getConnection();
				if (conn == null) {
					
					throw new BankException(
							"There is some problem with database connection.Please try again after some time");
				}
				preparedStatement = conn
						.prepareStatement(IQuerryMapper.GETCREDENTIALS);
				preparedStatement.setInt(1, accNum1);
				preparedStatement.setString(2, pswd);

				resultSet = preparedStatement.executeQuery();

				if (resultSet.next()) {
					usr = new User();
					usr.setAccountNumber(resultSet.getInt(1));
					usr.setPassword(resultSet.getString(2));
					
				}

			} catch (SQLException e) {
				e.printStackTrace();
				throw new BankException("Problem while inserting" + e);
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			return usr;
		}

		/*******************************************************************************************************
		- Function Name	    :	retrieveAll()
		- Input Parameters	:	
		- Return Type		:	List<UserInfoDTO>
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	retrieves all customer details
		********************************************************************************************************/
			

		@Override
		public List<User> retrieveAll() throws BankException {
			// TODO Auto-generated method stub
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			ArrayList<User> custList = new ArrayList<User>();
			User cust = null;
			conn = DBConnection.getConnection();

			try {
				preparedStatement = conn.prepareStatement(IQuerryMapper.RETRIEVEALL);
				resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					cust = new User();
					cust.setAccountNumber(resultSet.getInt(1));
					cust.setUserName(resultSet.getString(2));
					cust.setAge(resultSet.getInt(3));
					cust.setGender(resultSet.getString(4));
					cust.setAddress(resultSet.getString(5));
					cust.setMobile(resultSet.getString(6));
					cust.setEmail(resultSet.getString(7));
					cust.setPancard(resultSet.getString(8));
					cust.setAccountType(resultSet.getString(9));
					cust.setBalance(resultSet.getInt(10));
					cust.setSecurity(resultSet.getString(11));
					custList.add(cust);

				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BankException("Error in retrieval" + e);
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	

			return custList;
		}
		/*******************************************************************************************************
		- Function Name	    :	deleteCustomer()
		- Input Parameters	:	int accNo1
		- Return Type		:	boolean
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	deleting customer details using account number
		********************************************************************************************************/
			

		@Override
		public boolean deleteCustomer(int accNo1) throws BankException {
			// TODO Auto-generated method stub
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			int result;

			try {
				conn = DBConnection.getConnection();
				if (conn == null) {
					throw new BankException(
							"There is some problem with database connection.Please try again after some time");
				}
				preparedStatement = conn.prepareStatement(IQuerryMapper.DELETECUST);
				preparedStatement.setInt(1, accNo1);

				result = preparedStatement.executeUpdate();

				if (result > 0) {
					
					return true;
				} else{
					
					return false;}

			} catch (SQLException e) {
				e.printStackTrace();
				throw new BankException("Problem while deleting" + e);
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
		}
		
		/*******************************************************************************************************
		- Function Name	    :	retrieveFeeds()
		- Input Parameters	:	
		- Return Type		:	List<FeedbackDTO>
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	retrieves all customers feedbacks
		********************************************************************************************************/
			
		@Override
		public List<Feedback> retrieveFeeds() throws BankException {
			// TODO Auto-generated method stub
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			ArrayList<Feedback> feedList = new ArrayList<Feedback>();
			Feedback feed = null;
			conn = DBConnection.getConnection();

			try {
				preparedStatement = conn.prepareStatement(IQuerryMapper.GETFEEDS);
				resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					feed = new Feedback();
					feed.setAccNo(resultSet.getInt(1));
					feed.setAccHolder(resultSet.getString(2));
					feed.setMsg(resultSet.getString(3));
					feedList.add(feed);

				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BankException("Error in retrieval" + e);
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	

			return feedList;
		}

		/*******************************************************************************************************
		- Function Name	    :	addFeedback()
		- Input Parameters	:	
		- Return Type		:	Feedback
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	add customers feedbacks
		********************************************************************************************************/
		
		public Feedback addFeedback(Feedback addedFeed) throws BankException, SQLException {
			// TODO Auto-generated method stub
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			
			int result;
			
			ResultSet resultSet = null;
			
			try {
				conn = DBConnection.getConnection();
				if (conn == null) {
					throw new BankException(
							"There is some problem with database connection.Please try again after some time");
				}
				preparedStatement = conn.prepareStatement(IQuerryMapper.ADDFEED);
				preparedStatement.setInt(1, addedFeed.getAccNo());
				preparedStatement.setString(2, addedFeed.getAccHolder());
				preparedStatement.setString(3, addedFeed.getMsg());

				result = preparedStatement.executeUpdate();

			}finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			return addedFeed;
		}
		/*******************************************************************************************************
		- Function Name	    :	addCustomer()
		- Input Parameters	:	UserInfoDTO addedUser
		- Return Type		:	UserInfoDTO
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	adding customers
		********************************************************************************************************/

		public User addCustomer(User addedUser) throws BankException {
			// TODO Auto-generated method stub
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			PreparedStatement preparedStatement1 = null;
			PreparedStatement preparedStatement2 = null;
			PreparedStatement preparedStatement3 = null;
			int result;
			User custinfo = null;
			ResultSet resultSet = null;
			ResultSet resultSet1 = null;
			try {
				conn = DBConnection.getConnection();
				if (conn == null) {
					throw new BankException(
							"There is some problem with database connection.Please try again after some time");
				}
				preparedStatement = conn.prepareStatement(IQuerryMapper.ADDCUST);
				preparedStatement.setString(1, addedUser.getUserName());
				preparedStatement.setDate(3,(Date) addedUser.getDateOfBirth());
				preparedStatement.setString(4, addedUser.getGender());
				preparedStatement.setString(5, addedUser.getAddress());
				preparedStatement.setString(6, addedUser.getMobile());
				preparedStatement.setString(7, addedUser.getEmail());
				preparedStatement.setString(8, addedUser.getPancard());
				preparedStatement.setString(2, addedUser.getPassword());
				preparedStatement.setString(9, addedUser.getSecurity());

				result = preparedStatement.executeUpdate();

				if (result > 0) {
					preparedStatement1 = conn
							.prepareStatement(IQuerryMapper.GETACCID);
					resultSet = preparedStatement1.executeQuery();
					
				}else {
					
					throw new BankException("Insertion Failed");
				}

					
					if (resultSet.next()) {
						custinfo = new User();
						custinfo.setAccountNumber(resultSet.getInt(1));
						preparedStatement2 = conn
								.prepareStatement(IQuerryMapper.SETACCOUNT);
						preparedStatement2.setString(1, addedUser.getAccountType());
						int result1 = preparedStatement2.executeUpdate();

						if (result1 > 0) {
							preparedStatement3 = conn
									.prepareStatement(IQuerryMapper.RETRIEVECUST);
							preparedStatement3.setInt(1, custinfo.getAccountNumber());
						   resultSet1 = preparedStatement3
									.executeQuery();
						}
						else {
							
							throw new BankException("Id Retrieval Failed");
						}
							while (resultSet1.next()) {
								custinfo.setAccountNumber(resultSet1.getInt(1));
								custinfo.setUserName(resultSet1.getString(2));
								custinfo.setAge(resultSet1.getInt(3));
								custinfo.setGender(resultSet1.getString(4));
								custinfo.setAddress(resultSet1.getString(5));
								custinfo.setMobile(resultSet1.getString(6));
								custinfo.setEmail(resultSet1.getString(7));
								custinfo.setPancard(resultSet1.getString(8));
								custinfo.setAccountType(resultSet1.getString(9));
								custinfo.setBalance(resultSet1.getInt(10));
								custinfo.setSecurity(resultSet1.getString(11));

							}
								
							}
					
						

			} catch (SQLException e) {
				e.printStackTrace();
				throw new BankException("Error in retrieval" + e);
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			return custinfo;
		}

		/*******************************************************************************************************
		- Function Name	    :	getPersonalDetail()
		- Input Parameters	:	int accNo
		- Return Type		:	List<UserInfoDTO> 
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	retrieves personal details of customer
		********************************************************************************************************/
		
		public User getPersonalDetail(int accNo) throws BankException {
			// TODO Auto-generated method stub
			
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			User user=new User();
			//ArrayList<User> userList = new ArrayList<User>();
			//User user = null;
			conn = DBConnection.getConnection();
			try {
				preparedStatement = conn.prepareStatement(IQuerryMapper.PERSONALDETAILS);
				preparedStatement.setInt(1,accNo);
				resultSet = preparedStatement.executeQuery();
				if(resultSet.next()){
					//user = new User();
					user.setAccountNumber(resultSet.getInt(1));
					user.setUserName(resultSet.getString(2));
					user.setAge(resultSet.getInt(3));
					user.setGender(resultSet.getString(4));
					user.setAddress(resultSet.getString(5));
					user.setMobile(resultSet.getString(6));
					user.setEmail(resultSet.getString(7));
					user.setPancard(resultSet.getString(8));
					//userList.add(user);
			}
				
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("++++++++++++++++++++++++++++++++++++");
				throw new BankException("Error in retrieval" + e);
			}finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("************************************");
					throw new BankException("Technical Problem");

				}
			}	

			return user;

	}
			/*******************************************************************************************************
			- Function Name	    :	UpdateDetails()
			- Input Parameters	:	UserInfoDTO user3
			- Return Type		:	UserInfoDTO 
			- Throws			:  	BankException
			- Author			:	Capgemini-Group-3
			- Creation Date	    :	20/03/2017
			- Description		:	updates personal details of customer
			********************************************************************************************************/
		@Override
		public User UpdateDetails(User user3) throws BankException {
			// TODO Auto-generated method stub
			
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			int result = 0;
			User user = null;
			conn = DBConnection.getConnection();
			user = new User();
			
			ResultSet resultSet;
			
			try {
				
				preparedStatement = conn.prepareStatement(IQuerryMapper.UPDATEPERSONALDETAILS);
				
				preparedStatement.setString(1, user3.getAddress());
				preparedStatement.setString(2, user3.getMobile());
				preparedStatement.setString(3, user3.getEmail());
				preparedStatement.setInt(4, user3.getAccountNumber());
				
				result = preparedStatement.executeUpdate();
				
				if(result > 0){
					
					preparedStatement = conn.prepareStatement(IQuerryMapper.PERSONALDETAILS);
					preparedStatement.setInt(1, user3.getAccountNumber());
					resultSet = preparedStatement.executeQuery();
					
					if(resultSet.next()){
						
					user.setAccountNumber(resultSet.getInt(1));
					user.setUserName(resultSet.getString(2));
					user.setAge(resultSet.getInt(3));
					user.setGender(resultSet.getString(4));
					user.setAddress(resultSet.getString(5));
					user.setMobile(resultSet.getString(6));
					user.setEmail(resultSet.getString(7));
					user.setPancard(resultSet.getString(8));
					
					
					}
					
			}
				
			}catch (SQLException e) {
				e.printStackTrace();
				throw new BankException("Error in retrieval" + e);
			}finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	

			
			return user;
			
		}
		/*******************************************************************************************************
		- Function Name	    :	getAvlBalance()
		- Input Parameters	:	int accNo
		- Return Type		:	int
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	getting available balance
		********************************************************************************************************/
		
		@Override
		public int getAvlBalance(int accNo) throws BankException {
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			int bal =0;
			User user = null;
			conn = DBConnection.getConnection();
			try {
				preparedStatement = conn.prepareStatement(IQuerryMapper.CHECKBAL);
				preparedStatement.setInt(1,accNo);
				resultSet = preparedStatement.executeQuery();
				if(resultSet.next()){
					user = new User();
				 bal = resultSet.getInt(1);
				 
			} 
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BankException("Error in retrieval" + e);
			}finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			
			return bal;
		}
		/*******************************************************************************************************
		- Function Name	    :	changepwd()
		- Input Parameters	:	int accNo, String pwd
		- Return Type		:	boolean
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	changing password
		********************************************************************************************************/

		@Override
		public boolean changepwd(int accNo, String pwd) throws BankException {
			// TODO Auto-generated method stub
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			int result;
			
			try {
			conn =  DBConnection.getConnection();
			if (conn == null) {
				throw new BankException(
						"There is some problem with database connection.Please try again after some time");
			}
			preparedStatement = conn
					.prepareStatement(IQuerryMapper. CHANGEPWD);
			preparedStatement.setString(1, pwd);
			preparedStatement.setInt(2, accNo);
			result = preparedStatement.executeUpdate();
				if (result >0) {
					
					return true;
				}
				else{
					
					return false;}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BankException("Problem while inserting" + e);
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			
			
		}
		/*******************************************************************************************************
		- Function Name	    :	getStatus()
		- Input Parameters	:	int serviceID
		- Return Type		:	TrackerDTO 
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	retrieves the status for request generated by user
		********************************************************************************************************/
		@Override
		public Tracker getStatus(int serviceID) throws BankException {
			Tracker dto = new Tracker();
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			try {
				conn = DBConnection.getConnection();
				String sql = "SELECT service_ID,service_Description,Account_ID,service_Raised_Date,service_Status FROM ServiceTracker WHERE service_id=?";
				preparedStatement = conn.prepareStatement(sql);
				preparedStatement.setInt(1, serviceID);
				 resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					dto.setServiceID(resultSet.getInt(1));
					dto.setServiceDescription(resultSet.getString(2));
					dto.setAccountNumber(resultSet.getInt(3));
					dto.setServiceRaisedDate(resultSet.getDate(4));
					dto.setServiceStatus(resultSet.getString(5));
					
				}
				
				
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BankException("dao/sql/ERROR:"
						+ e.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
				throw new BankException("ERROR:" + e.getMessage());
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			return dto;
		}
		/*******************************************************************************************************
		- Function Name	    :	fundtransfer()
		- Input Parameters	:	int payerAccNo, int payeeAccNo, int amount
		- Return Type		:	UserInfoDTO
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	transfering amount between 2 accounts
		********************************************************************************************************/
		@Override
		public User fundtransfer(int payerAccNo, int payeeAccNo, int amount) throws BankException {
			// TODO Auto-generated method stub
			
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			User payerUsr = null;
			User payeeUsr = null;
			
			
			
		try {

			conn =  DBConnection.getConnection();
			if (conn == null) {
				
				throw new BankException(
					"There is some problem with database connection.Please try again after some time");
			}
			preparedStatement = conn.prepareStatement(IQuerryMapper.GETBALANCE);
			preparedStatement.setInt(1,payerAccNo);
			resultSet = preparedStatement.executeQuery();
			
			
			if(resultSet.next()){
				payerUsr=new User();
				
				payerUsr.setAccountNumber(resultSet.getInt(1));
				payerUsr.setAccountType(resultSet.getString(2));
				payerUsr.setBalance(resultSet.getInt(3));
				
				int payerBalance=payerUsr.getBalance();
				
				
				if(payerUsr.getBalance()>amount){
					
					payerBalance-=amount;
					
					preparedStatement = conn.prepareStatement(IQuerryMapper.FUNDTRANSFERPAYER);
					preparedStatement.setInt(1,payerBalance);
					preparedStatement.setInt(2,payerAccNo);
					resultSet = preparedStatement.executeQuery();
					
					preparedStatement = conn.prepareStatement(IQuerryMapper.TRANSACTIONINSERT);
					preparedStatement.setInt(5,payerAccNo);
					preparedStatement.setString(1,"Amount of "+ amount +" has been Debitted from your account to account Number "+ payeeAccNo);
					preparedStatement.setInt(2, amount);
					preparedStatement.setDate(3,Date.valueOf(LocalDate.now()));
					preparedStatement.setString(4, "Debitted");
					resultSet = preparedStatement.executeQuery();
					
					preparedStatement = conn.prepareStatement(IQuerryMapper.GETBALANCE);
					preparedStatement.setInt(1,payeeAccNo);
					resultSet = preparedStatement.executeQuery();
					
					if(resultSet.next()){
						payeeUsr=new User();
						payeeUsr.setAccountNumber(resultSet.getInt(1));
						payeeUsr.setAccountType(resultSet.getString(2));
						payeeUsr.setBalance(resultSet.getInt(3));
					
						int payeeBalance=payeeUsr.getBalance();
						
						
						payeeBalance+=amount;
						
					preparedStatement = conn.prepareStatement(IQuerryMapper.FUNDTRANSFERPAYEE);
					preparedStatement.setInt(1,payeeBalance);
					preparedStatement.setInt(2,payeeAccNo);
					
					resultSet = preparedStatement.executeQuery();
					
				
					preparedStatement = conn.prepareStatement(IQuerryMapper.TRANSACTIONINSERT);
					preparedStatement.setInt(5,payeeAccNo);
					preparedStatement.setString(1,"Amount of "+ amount + " has been creditted to your account from account Number "+ payerAccNo);
					preparedStatement.setInt(2, amount);
					preparedStatement.setDate(3,Date.valueOf(LocalDate.now()));
					preparedStatement.setString(4, "creditted");
					resultSet = preparedStatement.executeQuery();
					
					}
					
				}
					else
					
					{
						
						throw new  BankException("Your Balance is less than amount to transfer");
					}
					
			}
			else{
				
				throw new  BankException("Error in retrieval of balance of payer");
			}
			
			
		}catch (SQLException e) {
			e.printStackTrace();
			throw new BankException("Error in fund transfer" + e);
		}
		
		try {
			preparedStatement = conn.prepareStatement(IQuerryMapper.GETBALANCE);
			preparedStatement.setInt(1,payerAccNo);
			resultSet = preparedStatement.executeQuery();
			
			
			if(resultSet.next()){
				payerUsr=new User();
				
				payerUsr.setAccountNumber(resultSet.getInt(1));
				payerUsr.setAccountType(resultSet.getString(2));
				payerUsr.setBalance(resultSet.getInt(3));
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankException("Error in retrieval of balance of payer*" + e);
		}finally {
			
			try {
				
				if (conn != null)
					conn.close();
				if (preparedStatement != null)
					preparedStatement.close();
				
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BankException("Technical Problem");

			}
		}	
		
		
	return payerUsr;
		

	}
		/*******************************************************************************************************
		- Function Name	    :	requestCheckBook()
		- Input Parameters	:	int accNo, String requestItem
		- Return Type		:	int
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	user request for check book,credit card,debit card and passbook
		********************************************************************************************************/
		
		@Override
		public int requestCheckBook(int accNo, String requestItem) throws BankException{
			// TODO Auto-generated method stub
			
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			int serviceId = 0;
			 requestItem = requestItem.concat(" Request Processed Successfully");
			try {
				conn = DBConnection.getConnection();
				if(conn == null){
					
					
					throw new BankException("there is some problem in creating the database");
				}
				preparedStatement = conn.prepareStatement(IQuerryMapper.GETSERVICEQUERY);
				preparedStatement.setString(1, requestItem);
				preparedStatement.setInt(2, accNo);
				
				serviceId = preparedStatement.executeUpdate();
				
				
				if(serviceId > 0){
					preparedStatement=conn.prepareStatement(IQuerryMapper.GETSERVICEID);
					resultSet = preparedStatement.executeQuery();
					
				}
				else
				{
					throw new BankException("Service Creation Failed");
				}
				
				if(resultSet.next()){
					serviceId = resultSet.getInt(1);
					
				}
			}
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new BankException("Sql exception"+e);
				}finally {
					
					try {
						
						if (conn != null)
							conn.close();
						if (preparedStatement != null)
							preparedStatement.close();
						
					} catch (SQLException e) {
						e.printStackTrace();
						throw new BankException("Technical Problem");

					}
				}	
				
			return serviceId;
		}
		/*******************************************************************************************************
		- Function Name	    :	getTransDetails()
		- Input Parameters	:	int accNo
		- Return Type		:	List<TransactionDTO>
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	retrieves last 3 transaction details of account
		********************************************************************************************************/

		@Override
		public List<Transaction> getTransDetails(int accNo) throws BankException{
			// TODO Auto-generated method stub
			
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			ArrayList<Transaction> transList = new ArrayList<Transaction>();
			Transaction trans = null;
			conn = DBConnection.getConnection();
			try {
				preparedStatement = conn.prepareStatement(IQuerryMapper.GETMINISTATEMENT);
				preparedStatement.setInt(1,accNo);
				resultSet = preparedStatement.executeQuery();
				
				while(resultSet.next()){
					trans = new Transaction();
					trans.setTransactionId(resultSet.getInt(1));
					trans.setTransactionDescription(resultSet.getString(2));
					trans.setTransactionAmount(resultSet.getInt(3));
					trans.setTransactionDate(resultSet.getDate(4));
					trans.setTransactionType(resultSet.getString(5));
					transList.add(trans);
				}
				
				
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BankException("Error in retrieval" + e);
			}finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			return transList;
			}
		

		/*******************************************************************************************************
		- Function Name	    :	getDetailedTransDetails()
		- Input Parameters	:	int accNo
		- Return Type		:	List<TransactionDTO>
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	retrieves all transaction details of account
		********************************************************************************************************/
		
		@Override
		public List<Transaction> getDetailedTransDetails(int accNo)
				throws BankException {
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			ArrayList<Transaction> transList = new ArrayList<Transaction>();
			Transaction trans = null;
			conn = DBConnection.getConnection();
			try {
				preparedStatement = conn.prepareStatement(IQuerryMapper.GETDETAILEDSTATEMENT);
				preparedStatement.setInt(1,accNo);
				resultSet = preparedStatement.executeQuery();
				
				while(resultSet.next()){
					trans = new Transaction();
					trans.setTransactionId(resultSet.getInt(1));
					trans.setTransactionDescription(resultSet.getString(2));
					trans.setTransactionAmount(resultSet.getInt(3));
					trans.setTransactionDate(resultSet.getDate(4));
					trans.setTransactionType(resultSet.getString(5));
					transList.add(trans);
				}
				
				
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BankException("Error in retrieval" + e);
			}finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			return transList;
		}

		/*******************************************************************************************************
		- Function Name	    :	validateTransId()
		- Input Parameters	:	int trackid
		- Return Type		:	Tracker
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	validates trackID
		********************************************************************************************************/
		@Override
		public Tracker validateTransId(int trackid) throws BankException {
			
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			Tracker tr=null;
			//int accNum1 = Integer.parseInt(tranid);
			try{
				conn = DBConnection.getConnection();
				if (conn == null) {
					
					throw new BankException(
							"There is some problem with database connection.Please try again after some time");
				}
				preparedStatement = conn.prepareStatement(IQuerryMapper.GETACCNUM);
				preparedStatement.setInt(1, trackid);
				resultSet = preparedStatement.executeQuery();

				if (resultSet.next()) {
					tr = new Tracker();
					tr.setAccountNumber(resultSet.getInt(1));	
					
				}
			}catch(SQLException e){
				e.printStackTrace();
				throw new BankException("Technical Problem");
			}
			return tr;
		}

		/*******************************************************************************************************
		- Function Name	    :	retrievePassword()
		- Input Parameters	:	String accNum, String security
		- Return Type		:	User
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	retrives password
		********************************************************************************************************/
		@Override
		public User retrievePassword(String accNum, String security) throws BankException {
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			User usr = null;
			int accNum1 = Integer.parseInt(accNum);

			try {
				conn = DBConnection.getConnection();
				if (conn == null) {
					
					throw new BankException(
							"There is some problem with database connection.Please try again after some time");
				}
				preparedStatement = conn.prepareStatement(IQuerryMapper.RETRIEVE_PASSWORD);
				preparedStatement.setInt(1, accNum1);
				preparedStatement.setString(2,security);

				resultSet = preparedStatement.executeQuery();

				if (resultSet.next()) {
					usr = new User();
					usr.setPassword(resultSet.getString(1));
									
				}

			} catch (SQLException e) {
				e.printStackTrace();
				throw new BankException("Problem while inserting" + e);
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			return usr;
		}

		/*******************************************************************************************************
		- Function Name	    :	checkAdmin()
		- Input Parameters	:	String accNum, String password
		- Return Type		:	boolean
		- Throws			:  	BankException
		- Author			:	Capgemini-Group-3
		- Creation Date	    :	20/03/2017
		- Description		:	check if user is admin
		********************************************************************************************************/
		@Override
		public boolean checkAdmin(String accNum, String password) throws BankException {
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			boolean result=false;
			int accNum1 = Integer.parseInt(accNum);
			try {
				conn = DBConnection.getConnection();
				if (conn == null) {
					
					throw new BankException(
							"There is some problem with database connection.Please try again after some time");
				}
				preparedStatement = conn.prepareStatement(IQuerryMapper.GETADMIN);
				preparedStatement.setInt(1, accNum1);
				preparedStatement.setString(2,password);

				resultSet = preparedStatement.executeQuery();

				if (resultSet.next()) {
					result=true;
									
				}

			} catch (SQLException e) {
				e.printStackTrace();
				throw new BankException("Problem while inserting" + e);
			} finally {
				
				try {
					
					if (conn != null)
						conn.close();
					if (preparedStatement != null)
						preparedStatement.close();
					
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BankException("Technical Problem");

				}
			}	
			return result;
		}

}
