package com.cg.obs.dao;

public interface IQuerryMapper {
	
	static final String GETADMIN="SELECT * from admintab where admin_id=? and admin_password=?";
	
	static final String GETCREDENTIALS = "SELECT acc_no, pswd FROM USERTAB WHERE acc_no=? AND pswd=?";

	static final String RETRIEVEALL = "SELECT U.ACC_NO, U.CUSTNAME, ROUND((SYSDATE- U.DOB)/365), U.GENDER, U.ADDRESS, U.MOBILE, U.EMAIL_ID, U.PAN, T.ACC_TYPE, T.BALANCE , U.SECURITY FROM USERTAB U,ACCOUNTMAST T WHERE U.ACC_NO = T.ACC_NO ORDER BY U.ACC_NO";

	static final String DELETECUST = "DELETE FROM USERTAB WHERE acc_no=?";

	static final String GETFEEDS = "SELECT acc_no, acc_name, message FROM feedbacktab ORDER BY acc_no";

	static final String ADDCUST = "INSERT INTO USERTAB VALUES(ACCID_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?)";

	static final String GETACCID = "SELECT ACCID_SEQ.CURRVAL FROM DUAL";

	static final String SETACCOUNT = "INSERT INTO ACCOUNTMAST VALUES(ACCID_SEQ.CURRVAL,?,25000,SYSDATE)";

	static final String RETRIEVECUST = "SELECT U.ACC_NO, U.CUSTNAME, ROUND((SYSDATE- U.DOB)/365), U.GENDER, U.ADDRESS, U.MOBILE, U.EMAIL_ID, U.PAN, T.ACC_TYPE, T.BALANCE,U.SECURITY FROM USERTAB U, ACCOUNTMAST T WHERE U.ACC_NO = T.ACC_NO AND U.ACC_NO = ?";

	static final String PERSONALDETAILS = "SELECT U.ACC_NO, U.CUSTNAME, ROUND((SYSDATE- U.DOB)/365), U.GENDER, U.ADDRESS,U.MOBILE, U.EMAIL_ID,U.PAN FROM USERTAB U WHERE U.ACC_NO =?";

	static final String UPDATEPERSONALDETAILS = "UPDATE USERTAB SET ADDRESS=?,MOBILE = ?,EMAIL_ID = ? WHERE ACC_NO = ?";

	static final String CHECKBAL = " SELECT T.BALANCE FROM ACCOUNTMAST T WHERE T.ACC_NO = ?";

	static final String CHANGEPWD = " UPDATE USERTAB SET pswd =? WHERE acc_no=?";

	static final String GETBALANCE = "SELECT acc_no,acc_type,balance FROM accountmast WHERE acc_no=?";

	static final String FUNDTRANSFERPAYER = "UPDATE accountmast SET balance=? WHERE acc_no=?";

	static final String FUNDTRANSFERPAYEE = "UPDATE accountmast SET balance=? WHERE acc_no=?";

	static final String TRANSACTIONINSERT = "insert into TRANSACTIONS Values(transid_seq.NEXTVAL,?,?,?,?,?)";

	static final String GETSERVICEQUERY = "INSERT INTO ServiceTracker VALUES(track_seq.NEXTVAL,?,?,SYSDATE,'Open')";

	static final String GETSERVICEID = "SELECT track_seq.CURRVAL FROM DUAL";

	//static final String GETMINISTATEMENT = "SELECT trans_id,descrip,transacamount,transdate,transtype FROM TRANSACTIONS WHERE acc_no=?";
	
	static final String GETMINISTATEMENT="SELECT trans_id,descrip,transacamount,transdate,transtype FROM "
			+ "(select * from transactions order by rownum desc ) WHERE acc_no=? AND ROWNUM <=3";
	
	static final String GETDETAILEDSTATEMENT = "SELECT trans_id,descrip,transacamount,transdate,transtype FROM TRANSACTIONS WHERE acc_no=?";

	static final String SETFEED = "INSERT INTO feedbacktab VALUES(?,?,?)";

	static final String GETTRACK = "SELECT service_ID,service_Description,Account_ID,service_Raised_Date,service_Status FROM ServiceTracker WHERE service_id=?";

	static final String GETACCNUM="SELECT account_id from ServiceTracker WHERE service_id=?";
	
	/*String LOGIN_QUERY = "SELECT USERTYPE FROM USER_MASTER where USERNAME=? AND USERPASSWORD=?";*/
	
	String RETRIEVE_PASSWORD="SELECT pswd FROM USERTAB WHERE acc_no=? AND security=?";
	
	static final String ADDFEED = "INSERT INTO FEEDBACKTAB VALUES(?,?,?)";
}
