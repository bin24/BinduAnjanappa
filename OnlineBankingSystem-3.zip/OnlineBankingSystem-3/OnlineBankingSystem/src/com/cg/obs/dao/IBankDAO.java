package com.cg.obs.dao;

import java.util.List;

import com.cg.obs.dto.Feedback;
import com.cg.obs.dto.Tracker;
import com.cg.obs.dto.Transaction;
import com.cg.obs.dto.User;
import com.cg.obs.exception.BankException;

public interface IBankDAO {
	
List<User> retrieveAll() throws BankException;
	
	boolean deleteCustomer(int accNo1) throws BankException;
	
	List<Feedback> retrieveFeeds() throws BankException;
	
	User addCustomer(User addedUser) throws BankException;

	
	
	/***** New Func ******/
	
	
	//public List<User> getPersonalDetail(int accNo) throws BankException;
	public User getPersonalDetail(int accNo) throws BankException;
	
	public User UpdateDetails(User user3) throws BankException;
	
    public int getAvlBalance(int accNo) throws BankException;
	
	public boolean changepwd(int accNo, String pwd) throws BankException;
	
	public Tracker getStatus(int serviceID) throws BankException;
	
	User fundtransfer(int payerAccNo,int payeeAccNo,int amount) throws BankException;
	
	
	public int requestCheckBook(int accNo, String requestItem) throws BankException;
	
	
	public List<Transaction> getTransDetails(int accNo) throws BankException;
	
	public List<Transaction> getDetailedTransDetails(int accNo) throws BankException;

	User validateCredentials(String accNum, String pswd)
			throws BankException;
	public Tracker validateTransId(int trackid) throws BankException;
	
	public User retrievePassword(String accNo,String security) throws BankException;
	/*public String getUserType(String accNum, String password,String UserType) throws BankException;*/

	public boolean checkAdmin(String accNum,String password) throws BankException;
	

}
