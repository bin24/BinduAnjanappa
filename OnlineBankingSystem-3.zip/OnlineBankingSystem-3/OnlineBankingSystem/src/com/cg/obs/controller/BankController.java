package com.cg.obs.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.obs.dto.Feedback;
import com.cg.obs.dto.Tracker;
import com.cg.obs.dto.Transaction;
import com.cg.obs.dto.User;
import com.cg.obs.exception.BankException;
import com.cg.obs.service.BankServiceImpl;
import com.cg.obs.service.IBankService;

/**
 * Servlet implementation class BankController
 */
@WebServlet("*.obj")
public class BankController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public BankController() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @param accountNumber 
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = request.getServletPath().trim();
		String view = "";
		IBankService bankService = null;
		User user = null;
		int accountNumber = 0;
		System.out.println(path);
		switch(path){
		
		case "/about.obj":
			view = "AboutUs.jsp";
			break;
			
		case "/contact.obj":
			view = "ContactUs.jsp";
			break;
		
		case "/index.obj":
			view = "index.jsp";
			break;
			
		case "/admin.obj":
			view = "adminLogin.jsp";
			break;

		case "/user.obj":
			view = "userLogin.jsp";
			break;
			
		case "/userHome.obj":
			view = "userHome.jsp";
			break;
			
		case "/userLog.obj":
			
			String accountName = request.getParameter("accid");
			
			String password = request.getParameter("pwd");
			
			getServletContext().setAttribute("id", accountName);
			getServletContext().setAttribute("pass",password);
			
			try {
				bankService = new BankServiceImpl();
				User user1 = new User();
				
				//if("admin".equals(accountName)&&"admin123".equals(password)){
				if(bankService.checkAdmin(accountName, password)){	
				view="adminHome.jsp";
				}
				else if(bankService.validateCredentials(accountName,password)!=null){
					
					user1=bankService.validateCredentials(accountName,password);
					
					accountNumber = user1.getAccountNumber();
					System.out.println("account number=============="+accountNumber);
					password = user1.getPassword();
					view = "userHome.jsp";	
				}
				else
					view = "userLoginFail.jsp";
					
			} catch (BankException e) {
				e.printStackTrace();
			}
			break;
			
		case "/adminHome.obj":
			view = "adminHome.jsp";
			break;
			
		case "/adminLog.obj":
			view = "adminLog.jsp";
			break;
			
		case "/logout.obj":
			view = "logout.jsp";
			break;
			
		case "/forgotpassword.obj":
			view = "forgotpassword.jsp";	
			break;
			
		case "/retrivedpassword.obj":
			String accountName1 = request.getParameter("accid");
			String security = request.getParameter("security");
			try {
				bankService = new BankServiceImpl();
				User user1 = new User();
				
				if(bankService.retrievePassword(accountName1,security)!=null){
					//System.out.println(accountName1);
					user1=bankService.retrievePassword(accountName1,security);
					
					accountNumber = user1.getAccountNumber();
					security = user1.getPassword();
					getServletContext().setAttribute("user1", user1);
					view = "retrivedpassword.jsp";	
				}
				else
					view = "userLoginFail.jsp";
					
			} catch (BankException e) {
				e.printStackTrace();
			}
			break;
		
		case "/add.obj":
			view = "addCust.jsp";
			break;
		
		case "/feedback.obj":
			view = "feedback.jsp";
			break;
		
		case "/feedbackMessage.obj":
			bankService = new BankServiceImpl();
			Feedback newFeed = new Feedback();
			String account10=(String)getServletContext().getAttribute("id");
			int accNo=Integer.parseInt(account10);
			newFeed.setAccHolder(request.getParameter("cname"));
			newFeed.setAccNo(accNo);
			newFeed.setMsg(request.getParameter("feed"));
			try{
				Feedback addedFeed = new Feedback();
				addedFeed = bankService.addFeedback(newFeed);
				getServletContext().setAttribute("feed", addedFeed);
				view = "addedFeedback.jsp";
			} catch (BankException | SQLException  e) {
				request.setAttribute("error", e);
				view = "error.jsp";
			}
			
		break;
			
		case "/feed.obj":
			bankService = new BankServiceImpl();
			try {
				String account9=(String)getServletContext().getAttribute("id");
				List<Feedback> feedbackList = bankService.retrieveFeeds();
				getServletContext().setAttribute("feedList", feedbackList);
				view = "viewFeed.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "error.jsp";
			}
		break;
			
		case "/addDetails.obj":
			bankService = new BankServiceImpl();
			User newUser = new User();
			newUser.setUserName(request.getParameter("cname"));
			newUser.setDateOfBirth(java.sql.Date.valueOf(request.getParameter("cdob")));
			newUser.setGender(request.getParameter("gender"));
			newUser.setAddress(request.getParameter("address"));
			newUser.setMobile(request.getParameter("mob"));
			newUser.setEmail(request.getParameter("email"));
			newUser.setPancard(request.getParameter("pan"));
			newUser.setPassword(request.getParameter("pswd"));
			newUser.setAccountType(request.getParameter("accTyp"));
			newUser.setSecurity(request.getParameter("security"));
			try{
				User addedUser = new User();
				addedUser = bankService.addCustomer(newUser);
				getServletContext().setAttribute("cust", addedUser);
				view = "addedUser.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "error.jsp";
			}
			
			break;
			
		case "/viewAll.obj":
			bankService = new BankServiceImpl();
			try {
				List<User> customerList = bankService.retrieveAll();
				getServletContext().setAttribute("custList", customerList);
				view = "viewAll.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "error.jsp";
			}
			break;
			
		case "/delete.obj":
			bankService = new BankServiceImpl();
			try {
				List<User> customerList = bankService.retrieveAll();
				getServletContext().setAttribute("custList", customerList);
				view = "deleteUser.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "error.jsp";
			}
			
			break;
			
		case "/deleteSel.obj":
			int accountNumber1 = Integer.parseInt(request.getParameter("accid"));
			bankService = new BankServiceImpl();
			boolean deleteCust = false;
			try {
				getServletContext().setAttribute("delAccNo", accountNumber1);
				deleteCust = bankService.deleteCustomer(accountNumber1);
				if(deleteCust){
					List<User> customerList = bankService.retrieveAll();
					getServletContext().setAttribute("custList", customerList);
					view = "viewUpdatePage.jsp";
				}
					
				else{
					request.setAttribute("error", "Account Doesn't exist");
					view = "error.jsp";
					}
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "error.jsp";
			}
			
			break;			
		
			
			
		case "/register.obj":
			
			view = "register.jsp";
			break;
			
		case "/regAcc.obj":
			bankService = new BankServiceImpl();
			User newUser1 = new User();
			newUser1.setUserName(request.getParameter("cname"));
			newUser1.setDateOfBirth(java.sql.Date.valueOf(request.getParameter("cdob")));
			newUser1.setGender(request.getParameter("gender"));
			newUser1.setAddress(request.getParameter("address"));
			newUser1.setMobile(request.getParameter("mob"));
			newUser1.setEmail(request.getParameter("email"));
			newUser1.setPancard(request.getParameter("pan"));
			newUser1.setPassword(request.getParameter("pswd"));
			newUser1.setAccountType(request.getParameter("accTyp"));
			newUser1.setSecurity(request.getParameter("security"));
			try{
				User addedUser = new User();
				addedUser = bankService.addCustomer(newUser1);
				getServletContext().setAttribute("cust", addedUser);
				view = "registerSuccess.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "errorF.jsp";
			}
			
			break;
			
			
		case "/checkBal.obj":
			bankService = new BankServiceImpl();
			String account3=(String)getServletContext().getAttribute("id");
        	accountNumber=Integer.parseInt(account3);
			try {
				
				int balance = bankService.getAvlBalance(accountNumber);
				System.out.println("account number=============="+accountNumber);
				getServletContext().setAttribute("bal", balance);
				view = "checkBalance.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "errorF.jsp";
			}
			break;
			
		case "/personaldetails.obj":
			bankService = new BankServiceImpl();
			String account=(String)getServletContext().getAttribute("id");
        	accountNumber=Integer.parseInt(account);

			try {	
				User user1=(User) bankService.getPersonalDetail(accountNumber);
				getServletContext().setAttribute("user1", user1);
				view = "personaldetails.jsp";
				
				
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "errorF.jsp";
			}
			break;
			
			
		case "/EditDetails.obj" :			
			view = "EditDetails.jsp";
			break;
			
			
		case "/UpdateDetails.obj" :
			String account2=(String)getServletContext().getAttribute("id");
        	accountNumber=Integer.parseInt(account2);
			String ADDRESS = request.getParameter("ADDRESS");
			String MOBILE = request.getParameter("MOBILE");
			String EMAIL_ID = request.getParameter("EMAIL_ID");
			
			
			
			User user3 = new User();
			user3.setAccountNumber(accountNumber);
			user3.setAddress(ADDRESS);
			user3.setMobile(MOBILE);
			user3.setEmail(EMAIL_ID);
			
			
			bankService = new BankServiceImpl();
			User user2 = new User();
			try {
				user2 = bankService.UpdateDetails(user3);
				getServletContext().setAttribute("user", user2);
				view = "Updatedpersonaldetails.jsp";
				
			} catch (BankException e) {				
				request.setAttribute("error", e);
				view = "errorF.jsp";
			}
			
			break;
			
			
			
		case "/changePswd.obj":
			view="changePswd.jsp";
			break;
			
		case "/changePwd.obj":
			String account1=(String)getServletContext().getAttribute("id");
        	accountNumber=Integer.parseInt(account1);
			String pwd = request.getParameter("pwd");
			user = new User();
			user.setPassword(pwd);
			bankService = new BankServiceImpl();
			try {
				boolean result = bankService.changepwd(accountNumber,pwd);
				getServletContext().setAttribute("result", result);
				if(result){
				view = "changePwd.jsp";
				}
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "errorF.jsp";
			}	
			break;
			
		case "/track.obj":
			view = "track.jsp";
			break;
			
		case "/status.obj":
			bankService = new BankServiceImpl();
			String account4=(String)getServletContext().getAttribute("id");
        	accountNumber=Integer.parseInt(account4);
			try {
				bankService = new BankServiceImpl();
				Tracker trk=new Tracker();
				
				int serviceID = Integer.parseInt(request.getParameter("sid"));
				System.out.println(serviceID);
				if (bankService.validateTransId(serviceID)!= null) {

					trk = bankService.validateTransId(serviceID);

					int accountNum = trk.getAccountNumber();
					System.out.println("account num=============="
							+ accountNum);
				
				Tracker cust = bankService.getStatus(serviceID);
				if(accountNumber==accountNum){
				System.out.println(cust.toString());
				getServletContext().setAttribute("cust", cust);
				view = "status.jsp";
				}else{
					view="trackIderror.jsp";
					System.out.println("enter proper trackid");
				}
				}
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "errorF.jsp";
			}
			break;
			
		case "/fundTransfer.obj":   
			view = "fundTransfer.jsp";
			
		break;
		
		
		case "/fundtransferImpl.obj":
			String account8=(String)getServletContext().getAttribute("id");
			int payerAccNo = Integer.parseInt(account8);
			int payeeAccNo = Integer.parseInt(request.getParameter("payeeAccNo"));
			int transferAmount = Integer.parseInt(request.getParameter("transferAmount"));
			String payerPwd=request.getParameter("pwdTransfer");
			String pwsd=(String) getServletContext().getAttribute("pass");
			System.out.println(pwsd);
			bankService = new BankServiceImpl();
			try {

				if (payerAccNo != payeeAccNo && payerPwd.equals(pwsd)) {
					User payerObj = bankService.fundtransfer(payerAccNo,payeeAccNo, transferAmount);
					getServletContext().setAttribute("payerObj", payerObj);
					getServletContext().setAttribute("payeeAccNo", payeeAccNo);
					getServletContext().setAttribute("transferAmount",
							transferAmount);
					view = "transferFundSuccess.jsp";
				} else {
					throw new BankException(
							"Your transfering to your account.So, "
									+ "Please enter desired account number "
									+ "\n--OR--\n Invalid Password ");
				}

			} catch (BankException e) {
				e.printStackTrace();
				request.setAttribute("error", e);
				view = "errorF.jsp";
			}
			
		break;
		
		
		
		case "/request.obj" :
			
			bankService = new BankServiceImpl();
			String account6=(String)getServletContext().getAttribute("id");
        	accountNumber=Integer.parseInt(account6);
			try {
				String requestItem = request.getParameter("requestItem");
			int serviceId = bankService.requestCheckBook(accountNumber,requestItem);
			
			getServletContext().setAttribute("serviceId", serviceId);
			getServletContext().setAttribute("requestItem", requestItem);
			
			view = "requestSuccess.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "errorF.jsp";
			}
			
			break;
			
		case "/transaction.obj":
			view="transaction.jsp";
			break;
			
        case "/miniStatement.obj":
			
        	String account5=(String)getServletContext().getAttribute("id");
        	accountNumber=Integer.parseInt(account5);
        	bankService = new BankServiceImpl();
		
			try {
				
				List<Transaction> transactionList = bankService.getTransDetails(accountNumber);
				getServletContext().setAttribute("transList",transactionList);
				view = "viewTransdetails.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "error.jsp";
			}
			break;			
        
        case "/detailedStatement.obj":
			
        	String account7=(String)getServletContext().getAttribute("id");
        	accountNumber=Integer.parseInt(account7);
        	bankService = new BankServiceImpl();
		
			try {
				
				List<Transaction> transactionList = bankService.getDetailedTransDetails(accountNumber);
				getServletContext().setAttribute("transList",transactionList);
				view = "viewTransdetails.jsp";
			} catch (BankException e) {
				request.setAttribute("error", e);
				view = "error.jsp";
			}
			break;
        
        case "/requestService.obj":
        	view = "requestPage.jsp";
        	break;
			
		
		default: 
			break;

		}
		
		RequestDispatcher dispatcher=request.getRequestDispatcher(view);
		dispatcher.forward(request, response);
		
	}
	}

