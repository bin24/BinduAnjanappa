package com.cg.obs.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.obs.dao.BankDAOImpl;
import com.cg.obs.dto.Feedback;
import com.cg.obs.dto.Tracker;
import com.cg.obs.dto.Transaction;
import com.cg.obs.dto.User;
import com.cg.obs.exception.BankException;

public class BankServiceImpl implements IBankService {

	@Override
	public User validateCredentials(String accNum,String pswd) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().validateCredentials(accNum,pswd);
	}

	@Override
	public List<User> retrieveAll() throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().retrieveAll();
	}

	@Override
	public boolean deleteCustomer(int accNo1) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().deleteCustomer(accNo1);
	}

	@Override
	public List<Feedback> retrieveFeeds() throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().retrieveFeeds() ;
	}

	@Override
	public User addCustomer(User addedUser)  throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().addCustomer(addedUser);
	}

	@Override
	public User getPersonalDetail(int accNo) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl(). getPersonalDetail(accNo);
	}
	
	@Override
	public User UpdateDetails(User user3) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().UpdateDetails(user3);
	}
	
	@Override
	public int getAvlBalance(int accNo) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().getAvlBalance(accNo);
	}

	@Override
	public boolean changepwd(int accNo, String pwd) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().changepwd(accNo,pwd);
	}
	
	@Override
	public Tracker getStatus(int serviceID) throws BankException {
		
		return new BankDAOImpl().getStatus(serviceID);
		
	}
	
	@Override
	public User fundtransfer(int payerAccNo, int payeeAccNo, int amount) throws BankException {
		return new BankDAOImpl().fundtransfer(payerAccNo, payeeAccNo, amount);
	}

	
	@Override
	public int requestCheckBook(int accNo,String requestItem) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().requestCheckBook(accNo,requestItem);
	}
	
	@Override
	public List<Transaction> getTransDetails(int accNo) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().getTransDetails(accNo);
	}

	@Override
	public Tracker validateTransId(int trackid) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().getStatus(trackid);
	}

	@Override
	public User retrievePassword(String accNo, String security) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().retrievePassword(accNo, security);
	}

	@Override
	public List<Transaction> getDetailedTransDetails(int accNo)
			throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().getDetailedTransDetails(accNo);
	}

	@Override
	public Feedback addFeedback(Feedback addedFeed) throws BankException, SQLException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().addFeedback(addedFeed);
		
	}

	@Override
	public boolean checkAdmin(String accNum, String password) throws BankException {
		// TODO Auto-generated method stub
		return new BankDAOImpl().checkAdmin(accNum,password);
	}

}
