package com.cg.obs.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.obs.exception.BankException;

public class DBConnection {

	static Connection connection;

	public static Connection getConnection() throws BankException {

		try {

			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleNewDS");
			connection = ds.getConnection();
		} catch (SQLException e) {
			throw new BankException("SQL Error:" + e.getMessage());

		} catch (NamingException e) {

		}
		return connection;
	}
}
